package com.example.SpringRestPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
