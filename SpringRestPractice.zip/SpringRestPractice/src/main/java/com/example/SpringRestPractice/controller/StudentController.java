package com.example.SpringRestPractice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringRestPractice.entity.Student;
import com.example.SpringRestPractice.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	StudentService stdService;
	
	@GetMapping("/api/student")
	public List<Student> getAllStudents(Student std) {
		return stdService.getAllStd();
		
	}
	
	@GetMapping("/api/student/{id}")
	public Student getById(@PathVariable("id") int id) {
		 return stdService.getStdBy(id);
	}
	
	@PostMapping("/api/student")
	public Student saveStudent(@RequestBody Student std) {
		return stdService.saveStd(std);
	}
	
	@PutMapping("/api/student/{id}")
	public Student updateStudent(@PathVariable("id") int id, @RequestBody Student std) {
		return stdService.updateStd(id, std);
	}
	
	@DeleteMapping("/api/student/{id}")
	public Student deleteStudent(@PathVariable ("id") int id) {
		return stdService.removeStd(id);
	}	
	
}
