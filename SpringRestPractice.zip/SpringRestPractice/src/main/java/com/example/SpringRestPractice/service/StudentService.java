package com.example.SpringRestPractice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringRestPractice.entity.Student;
import com.example.SpringRestPractice.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	StudentRepository studentRepo;

	public Student saveStd(Student std) {
		return studentRepo.save(std);

	}

	public List<Student> getAllStd() {
		return studentRepo.findAll();
	}

	public Student getStdBy(int id) {
		Optional<Student> optStd = studentRepo.findById(id);

		if (optStd.isPresent()) {
			Student s = optStd.get();
			return s;
		}
		return null;
	}

	public Student updateStd(int id, Student std) {

		Optional<Student> optStd = studentRepo.findById(id);

		if (optStd.isPresent()) {
			Student s = optStd.get();
			s.setName(std.getName());
			s.setQualification(std.getQualification());
			s.setCity(std.getCity());
			studentRepo.save(s);

		}

		return null;
	}

	public Student removeStd(int id) {
		Optional<Student> optStd = studentRepo.findById(id);

		if (optStd.isPresent()) {
			Student s = optStd.get();
			studentRepo.delete(s);
		}
		return null;
	}

}
