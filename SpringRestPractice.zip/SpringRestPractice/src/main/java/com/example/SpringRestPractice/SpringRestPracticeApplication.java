package com.example.SpringRestPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestPracticeApplication.class, args);
	}

}
